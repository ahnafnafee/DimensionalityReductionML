# Dimensionality Reduction

### Question 1

> N/A

### Question 2

1. Install opencv using `conda install opencv`
2. It's assumed that the *yaleface* directory is located at `.\yalefaces\` 
3. It's assumed all the yalefaces files already exist in the subdirectory (no exist check is done here)



### Question 3

1. Also requires opencv
2. Video saved in the root directory